package ru.example.autoah;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

public class GrindTask {
    private enum State {
        IDLE, WALK_BOOK_CHEST, OPEN_BOOK_CHEST, TAKE_BOOKS,
        WALK_SWORD_CHEST, OPEN_SWORD_CHEST, TAKE_SWORDS,
        FIGHT, WALK_ANVIL, OPEN_ANVIL, COMBINE, SELL
    }

    private State state = State.IDLE;
    private int wait = 0;
    private LivingEntity target;
    private long lastAttack = 0;
    private int combineStep = 0; // какая книга сейчас: 0 острота, 1 починка, 2 неразрушимость

    public void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        ModConfig cfg = ConfigManager.cfg;
        if (!cfg.enabled) { state = State.IDLE; target = null; return; }
        if (wait > 0) { wait--; return; }

        ClientPlayerEntity p = client.player;

        switch (state) {
            case IDLE -> {
                if (hasItemsForCycle(client, cfg)) state = State.FIGHT;
                else if (cfg.bookChest != null) state = State.WALK_BOOK_CHEST;
                else { stop(cfg, "Задай сундук с книгами в меню (RShift)"); }
            }

            // ---- СУНДУК С КНИГАМИ ----
            case WALK_BOOK_CHEST -> {
                if (!walkTo(p, center(cfg.bookChest), 4.0)) break;
                state = State.OPEN_BOOK_CHEST;
            }
            case OPEN_BOOK_CHEST -> {
                openBlock(client, cfg.bookChest);
                if (client.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
                    state = State.TAKE_BOOKS;
                } else wait = 10; // ретрай
            }
            case TAKE_BOOKS -> {
                if (!(p.currentScreenHandler instanceof GenericContainerScreenHandler h)) { wait = 5; break; }
                int sharp = cfg.sharpBooks - countInv(p, s -> isBook(s, Enchantments.SHARPNESS, 5));
                int mend  = cfg.mendingBooks - countInv(p, s -> isBook(s, Enchantments.MENDING, 1));
                int unb   = cfg.unbreakingBooks - countInv(p, s -> isBook(s, Enchantments.UNBREAKING, 3));
                if (sharp <= 0 && mend <= 0 && unb <= 0) {
                    client.player.closeHandledScreen();
                    state = cfg.swordChest != null ? State.WALK_SWORD_CHEST : State.FIGHT;
                    break;
                }
                if (!clickFirstMatch(client, h, s -> {
                    if (sharp > 0 && isBook(s, Enchantments.SHARPNESS, 5)) return true;
                    if (mend > 0 && isBook(s, Enchantments.MENDING, 1)) return true;
                    return unb > 0 && isBook(s, Enchantments.UNBREAKING, 3);
                })) {
                    client.player.closeHandledScreen();
                    stop(cfg, "В сундуке закончились книги");
                }
                wait = 2;
            }

            // ---- СУНДУК С МЕЧАМИ ----
            case WALK_SWORD_CHEST -> {
                if (!walkTo(p, center(cfg.swordChest), 4.0)) break;
                state = State.OPEN_SWORD_CHEST;
            }
            case OPEN_SWORD_CHEST -> {
                openBlock(client, cfg.swordChest);
                if (p.currentScreenHandler instanceof GenericContainerScreenHandler) state = State.TAKE_SWORDS;
                else wait = 10;
            }
            case TAKE_SWORDS -> {
                if (!(p.currentScreenHandler instanceof GenericContainerScreenHandler h)) { wait = 5; break; }
                int need = cfg.swordsPerCycle - countInv(p, s -> s.getItem() == Items.DIAMOND_SWORD);
                if (need <= 0) {
                    client.player.closeHandledScreen();
                    state = State.FIGHT;
                    break;
                }
                if (!clickFirstMatch(client, h, s -> s.getItem() == Items.DIAMOND_SWORD)) {
                    client.player.closeHandledScreen();
                    stop(cfg, "В сундуке закончились мечи");
                }
                wait = 2;
            }

            // ---- ФАРМ ОПЫТА ----
            case FIGHT -> {
                if (p.experienceLevel >= cfg.xpTarget) { target = null; state = State.WALK_ANVIL; break; }
                if (target == null || !target.isAlive() || p.distanceTo(target) > cfg.searchRadius + 4)
                    target = findNearest(client, cfg);

                if (target == null) { wait = 20; break; }

                double dist = p.distanceTo(target);
                Vec3d to = target.getPos().add(0, target.getHeight() / 2, 0).subtract(p.getEyePos()).normalize();
                float yaw = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
                float pitch = (float) -Math.toDegrees(Math.asin(to.y));
                p.setYaw(yaw); p.setPitch(pitch);

                if (dist > cfg.reach) {
                    Vec3d flat = new Vec3d(to.x, 0, to.z).normalize().multiply(0.25);
                    p.setVelocity(flat.x, p.getVelocity().y, flat.z);
                    p.setSprinting(true);
                } else if (dist < cfg.reach - 0.3) {
                    Vec3d flat = new Vec3d(to.x, 0, to.z).normalize().multiply(-0.15);
                    p.setVelocity(flat.x, p.getVelocity().y, flat.z);
                } else {
                    // держим дистанцию 1.25 — орбитим вокруг моба
                    Vec3d side = new Vec3d(-to.z, 0, to.x).normalize().multiply(0.1);
                    p.setVelocity(side.x, p.getVelocity().y, side.z);
                    long now = System.currentTimeMillis();
                    if (now - lastAttack >= cfg.attackDelayMs) {
                        selectStack(client, s -> s.getItem() == Items.DIAMOND_SWORD);
                        client.interactionManager.attackEntity(p, target);
                        p.swingHand(Hand.MAIN_HAND);
                        lastAttack = now;
                    }
                }
            }

            // ---- НАКОВАЛЬНЯ ----
            case WALK_ANVIL -> {
                if (cfg.anvilPos == null) { stop(cfg, "Задай наковальню в меню (RShift)"); break; }
                if (!walkTo(p, center(cfg.anvilPos), 4.0)) break;
                state = State.OPEN_ANVIL;
            }
            case OPEN_ANVIL -> {
                openBlock(client, cfg.anvilPos);
                if (p.currentScreenHandler instanceof AnvilScreenHandler) { combineStep = 0; state = State.COMBINE; }
                else wait = 10;
            }
            case COMBINE -> {
                if (!(p.currentScreenHandler instanceof AnvilScreenHandler h)) { wait = 5; break; }
                // 0 = кладём меч, 1 = кладём книгу, 2 = забираем результат, 3 = убираем книгу из слота
                switch (combineStep % 4) {
                    case 0 -> { if (h.getSlot(0).hasStack()) { combineStep++; break; }
                        if (!moveFromInv(client, h, s -> s.getItem() == Items.DIAMOND_SWORD && !s.hasEnchantments()))
                            failAnvil(client, cfg); }
                    case 1 -> { if (h.getSlot(1).hasStack()) { combineStep++; break; }
                        if (!moveFromInv(client, h, nextBookPredicate(cfg))) failAnvil(client, cfg); }
                    case 2 -> { if (h.getSlot(2).hasStack()) {
                            client.interactionManager.clickSlot(h.syncId, 2, 0, SlotActionType.QUICK_MOVE, p);
                            combineStep++; } }
                    case 3 -> { // слот 1 всё ещё занят старой книгой — убираем
                        if (h.getSlot(1).hasStack())
                            client.interactionManager.clickSlot(h.syncId, 1, 0, SlotActionType.QUICK_MOVE, p);
                        combineStep++; }
                }
                wait = 3;
                if (combineStep >= cfgBookCount(cfg) * 4) {
                    client.player.closeHandledScreen();
                    state = State.SELL;
                }
            }

            // ---- ПРОДАЖА ----
            case SELL -> {
                selectStack(client, s -> s.getItem() == Items.DIAMOND_SWORD && s.hasEnchantments());
                p.networkHandler.sendChatCommand("ah sell " + cfg.sellPrice);
                wait = 40; // ждём снятие с продажи/регистрацию лота
                if (hasItemsForCycle(client, cfg)) state = State.FIGHT;
                else if (cfg.bookChest != null) state = State.WALK_BOOK_CHEST;
                else stop(cfg, "Ресурсы закончились");
            }
        }
    }

    // ---------- утилиты ----------

    private void stop(ModConfig cfg, String msg) {
        cfg.enabled = false;
        ConfigManager.save();
        state = State.IDLE;
        System.out.println("[AutoAH] Остановлено: " + msg);
    }

    private void failAnvil(MinecraftClient client, ModConfig cfg) {
        client.player.closeHandledScreen();
        stop(cfg, "Не хватает предметов/опыта для зачарования");
    }

    private int cfgBookCount(ModConfig c) {
        return c.sharpBooks + c.mendingBooks + c.unbreakingBooks;
    }

    private Predicate<ItemStack> nextBookPredicate(ModConfig cfg) {
        int i = combineStep / 4;
        if (i < cfg.sharpBooks) return s -> isBook(s, Enchantments.SHARPNESS, 5);
        i -= cfg.sharpBooks;
        if (i < cfg.mendingBooks) return s -> isBook(s, Enchantments.MENDING, 1);
        return s -> isBook(s, Enchantments.UNBREAKING, 3);
    }

    private boolean hasItemsForCycle(MinecraftClient c, ModConfig cfg) {
        ClientPlayerEntity p = c.player;
        return countInv(p, s -> s.getItem() == Items.DIAMOND_SWORD && !s.hasEnchantments()) >= cfg.swordsPerCycle
                && countInv(p, s -> isBook(s, Enchantments.SHARPNESS, 5)) >= cfg.sharpBooks
                && countInv(p, s -> isBook(s, Enchantments.MENDING, 1)) >= cfg.mendingBooks
                && countInv(p, s -> isBook(s, Enchantments.UNBREAKING, 3)) >= cfg.unbreakingBooks;
    }

    private static boolean isBook(ItemStack s, RegistryEntry<Enchantment> ench, int lvl) {
        if (!s.isOf(Items.ENCHANTED_BOOK)) return false;
        ItemEnchantmentsComponent c = s.get(DataComponentTypes.STORED_ENCHANTMENTS);
        return c != null && c.getLevel(ench) >= lvl;
    }

    private int countInv(ClientPlayerEntity p, Predicate<ItemStack> pred) {
        int n = 0;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && pred.test(s)) n += s.getCount();
        }
        return n;
    }

    private boolean clickFirstMatch(MinecraftClient c, GenericContainerScreenHandler h, Predicate<ItemStack> pred) {
        // слоты сундука идут первыми (до - 36 слотов инвентаря)
        int chestSlots = h.slots.size() - 36;
        for (int i = 0; i < chestSlots; i++) {
            Slot slot = h.getSlot(i);
            if (slot.hasStack() && pred.test(slot.getStack())) {
                c.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, c.player);
                return true;
            }
        }
        return false;
    }

    private boolean moveFromInv(MinecraftClient c, net.minecraft.screen.ScreenHandler h, Predicate<ItemStack> pred) {
        // слоты контейнера идут первыми, инвентарь игрока — последние 36
        int start = h.slots.size() - 36;
        for (int i = start; i < h.slots.size(); i++) {
            Slot slot = h.getSlot(i);
            if (slot.hasStack() && pred.test(slot.getStack())) {
                c.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, c.player);
                return true;
            }
        }
        return false;
    }

    private void selectStack(MinecraftClient c, Predicate<ItemStack> pred) {
        ClientPlayerEntity p = c.player;
        for (int i = 0; i < 9; i++) {
            if (pred.test(p.getInventory().getStack(i))) {
                p.getInventory().selectedSlot = i;
                return;
            }
        }
        // если в хотбаре нет — ищем в инвентаре
        for (int i = 9; i < p.getInventory().size(); i++) {
            if (pred.test(p.getInventory().getStack(i))) {
                p.getInventory().selectedSlot = Math.min(i, 8);
                return;
            }
        }
    }

    private LivingEntity findNearest(MinecraftClient c, ModConfig cfg) {
        LivingEntity best = null; double bd = cfg.searchRadius;
        for (var e : c.world.getEntities()) {
            if (e instanceof HostileEntity m && m.isAlive()) {
                double d = c.player.distanceTo(m);
                if (d < bd) { bd = d; best = m; }
            }
        }
        return best;
    }

    private boolean walkTo(ClientPlayerEntity p, Vec3d target, double stopDist) {
        Vec3d d = target.subtract(p.getPos());
        double len = d.length();
        if (len <= stopDist) return true;
        Vec3d flat = new Vec3d(d.x, 0, d.z).normalize().multiply(Math.min(0.3, len * 0.1));
        p.setVelocity(flat.x, p.getVelocity().y, flat.z);
        p.setSprinting(true);
        p.setYaw((float) Math.toDegrees(Math.atan2(-flat.x, flat.z)));
        return false;
    }

    private Vec3d center(int[] pos) {
        return new Vec3d(pos[0] + 0.5, pos[1], pos[2] + 0.5);
    }

    private void openBlock(MinecraftClient c, int[] pos) {
        BlockPos bp = new BlockPos(pos[0], pos[1], pos[2]);
        BlockHitResult hit = new BlockHitResult(bp.toCenterPos(), Direction.UP, bp, false);
        c.interactionManager.interactBlock(c.player, Hand.MAIN_HAND, hit);
    }
}
