package ru.example.autoah;

public class ModConfig {
    public boolean enabled = false;
    public String sellPrice = "500k";
    public int xpTarget = 13;
    public int attackDelayMs = 500;
    public double reach = 1.25;
    public double searchRadius = 16;

    // сколько предметов тратится за один цикл
    public int swordsPerCycle = 1;
    public int sharpBooks = 1;
    public int mendingBooks = 1;
    public int unbreakingBooks = 1;

    // координаты блоков [x, y, z]; null = не задано
    public int[] bookChest = null;
    public int[] swordChest = null;
    public int[] anvilPos = null;
}
