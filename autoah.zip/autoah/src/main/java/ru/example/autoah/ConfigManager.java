package ru.example.autoah;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ConfigManager {
    public static ModConfig cfg = new ModConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance()
            .getConfigDir().resolve("autoah.json");

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                cfg = GSON.fromJson(Files.readString(FILE), ModConfig.class);
                if (cfg == null) cfg = new ModConfig();
            } else save();
        } catch (Exception e) {
            cfg = new ModConfig();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(cfg));
        } catch (IOException ignored) {}
    }
}
