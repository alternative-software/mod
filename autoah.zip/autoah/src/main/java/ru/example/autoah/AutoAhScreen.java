package ru.example.autoah;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class AutoAhScreen extends Screen {
    public String lookMode = null; // book / sword / anvil
    private TextFieldWidget sellPrice, xpTarget, delay, reach, radius,
            sharp, mend, unb, swords;

    public AutoAhScreen() { super(Text.literal("AutoAH")); }

    @Override
    protected void init() {
        int x = width / 2 - 100, y = 30;
        ModConfig c = ConfigManager.cfg;

        sellPrice = field(x, y, c.sellPrice);                 y += 22;
        xpTarget  = field(x, y, String.valueOf(c.xpTarget));  y += 22;
        delay     = field(x, y, String.valueOf(c.attackDelayMs)); y += 22;
        reach     = field(x, y, String.valueOf(c.reach));     y += 22;
        radius    = field(x, y, String.valueOf(c.searchRadius)); y += 22;
        swords    = field(x, y, String.valueOf(c.swordsPerCycle)); y += 22;
        sharp     = field(x, y, String.valueOf(c.sharpBooks)); y += 22;
        mend      = field(x, y, String.valueOf(c.mendingBooks)); y += 22;
        unb       = field(x, y, String.valueOf(c.unbreakingBooks)); y += 26;

        addDrawableChild(ButtonWidget.builder(Text.literal("Сундук книг: " + fmt(c.bookChest)), b -> {
            lookMode = "book";
        }).dimensions(x, y, 200, 20).build()); y += 24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Сундук мечей: " + fmt(c.swordChest)), b -> {
            lookMode = "sword";
        }).dimensions(x, y, 200, 20).build()); y += 24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Наковальня: " + fmt(c.anvilPos)), b -> {
            lookMode = "anvil";
        }).dimensions(x, y, 200, 20).build()); y += 26;

        addDrawableChild(ButtonWidget.builder(Text.literal(c.enabled ? "§aВключено" : "§cВыключено"), b -> {
            c.enabled = !c.enabled; apply(); b.setMessage(Text.literal(c.enabled ? "§aВключено" : "§cВыключено"));
        }).dimensions(x, y, 200, 20).build()); y += 26;

        addDrawableChild(ButtonWidget.builder(Text.literal("Сохранить и закрыть"), b -> { apply(); close(); })
                .dimensions(x, y, 200, 20).build());
    }

    private TextFieldWidget field(int x, int y, String val) {
        TextFieldWidget t = new TextFieldWidget(textRenderer, x, y, 200, 18, Text.empty());
        t.setText(val);
        addDrawableChild(t);
        return t;
    }

    private String fmt(int[] p) { return p == null ? "не задано (нажми + смотри)" : p[0] + " " + p[1] + " " + p[2]; }

    private void apply() {
        ModConfig c = ConfigManager.cfg;
        try {
            c.sellPrice = sellPrice.getText();
            c.xpTarget = Integer.parseInt(xpTarget.getText().trim());
            c.attackDelayMs = Integer.parseInt(delay.getText().trim());
            c.reach = Double.parseDouble(reach.getText().trim());
            c.searchRadius = Double.parseDouble(radius.getText().trim());
            c.swordsPerCycle = Integer.parseInt(swords.getText().trim());
            c.sharpBooks = Integer.parseInt(sharp.getText().trim());
            c.mendingBooks = Integer.parseInt(mend.getText().trim());
            c.unbreakingBooks = Integer.parseInt(unb.getText().trim());
        } catch (Exception ignored) {}
        ConfigManager.save();
    }

    @Override
    public void render(net.minecraft.client.gui.DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        int x = width / 2 - 100, y = 30;
        ctx.drawText(textRenderer, "Цена продажи (/ah sell)", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Цель уровня XP", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Задержка удара (мс)", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Дистанция до моба", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Радиус поиска мобов", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Мечей за цикл", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Книг Острота V", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Книг Починка", x - 140, y + 5, 0xFFFFFF, true); y += 22;
        ctx.drawText(textRenderer, "Книг Прочность III", x - 140, y + 5, 0xFFFFFF, true);
        if (lookMode != null)
            ctx.drawCenteredTextWithShadow(textRenderer, "§eПрицелься в блок и нажми сюда снова...", width / 2, 12, 0xFFFF00);
        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
