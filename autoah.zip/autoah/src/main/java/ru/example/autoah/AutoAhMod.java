package ru.example.autoah;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.hit.BlockHitResult;
import org.lwjgl.glfw.GLFW;

public class AutoAhMod implements ClientModInitializer {
    public static KeyBinding openGuiKey;
    public static final GrindTask task = new GrindTask();

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autoah.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "AutoAH"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.wasPressed()) client.setScreen(new AutoAhScreen());

            // захват блока взглядом для кнопок "указать взглядом"
            if (client.currentScreen instanceof AutoAhScreen screen && screen.lookMode != null
                    && client.crosshairTarget instanceof BlockHitResult hit) {
                int[] pos = {hit.getBlockPos().getX(), hit.getBlockPos().getY(), hit.getBlockPos().getZ()};
                switch (screen.lookMode) {
                    case "book"  -> ConfigManager.cfg.bookChest = pos;
                    case "sword" -> ConfigManager.cfg.swordChest = pos;
                    case "anvil" -> ConfigManager.cfg.anvilPos = pos;
                }
                screen.lookMode = null;
                ConfigManager.save();
            }
            task.tick(client);
        });
    }
}
